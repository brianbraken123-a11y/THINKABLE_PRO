/* Isi dengan nomor bisnis yang sudah diverifikasi, format internasional tanpa +. */
const BUSINESS_CONFIG = { whatsappNumber: '628789558215' };
const form = document.querySelector('#consult-form');
const status = document.querySelector('#form-status');
document.querySelectorAll('[data-package]').forEach(link => link.addEventListener('click', () => { form.elements.package.value = link.dataset.package; }));
form.addEventListener('submit', event => {
 event.preventDefault();
 const data = new FormData(form);
 const message = `Halo Thinkable.pro! Saya ingin konsultasi gratis.\n\nNama: ${data.get('name').trim()}\nUsaha / profesi: ${data.get('business').trim()}\nPaket: ${data.get('package')}\nKebutuhan: ${data.get('needs').trim() || 'Ingin diskusi dulu.'}\n\nMohon info cakupan paket, domain, hosting, dan biaya perpanjangannya.`;
 const number = BUSINESS_CONFIG.whatsappNumber;
 if (!/^[1-9]\d{7,14}$/.test(number)) {
  status.textContent = 'Kontak WhatsApp belum tersedia. Pesanmu sudah disiapkan dan dapat disalin; belum ada pesan yang dikirim.';
  document.querySelector('#fallback').hidden = false;
  document.querySelector('#message').value = message;
  return;
 }
 status.textContent = 'Melanjutkan ke WhatsApp. Periksa pesan sebelum mengirim.';
 window.location.href = `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
});
document.querySelector('#copy-message').addEventListener('click', async () => {
 const field = document.querySelector('#message');
 try { await navigator.clipboard.writeText(field.value); status.textContent = 'Pesan berhasil disalin.'; }
 catch { field.focus(); field.select(); status.textContent = 'Pilih dan salin pesan di atas secara manual.'; }
});
